import pygame
import random
import math
from os import path
import time

img_dir = path.join(path.dirname(__file__), 'img')

# Constants
WIDTH = 800
HEIGHT = 600
FPS = 30
UNIT = 48

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
PURPLE = (255, 0, 255)
CYAN = (0, 255, 255)

class Goomba(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(goomba_img, (UNIT,UNIT))
        self.image.set_colorkey(WHITE)
        self.rect = self.image.get_rect()

        self.rect.bottom = 5*UNIT
        self.rect.left = 1*UNIT

        self.x_vel = UNIT/16
        self.frame = 0
        self.animation_state = 0

    def update(self):
        self.rect.x += self.x_vel
        self.frame += 1

        collisions = pygame.sprite.spritecollide(self, brick_list, False)
        if collisions:
            if self.x_vel > 0:
                self.rect.right = collisions[0].rect.left
            else:
                self.rect.left = collisions[0].rect.right
            self.x_vel *= -1
        
        if self.frame % 8 == 0:
            self.animation_state = (self.animation_state + 1) % 2
            if self.animation_state == 0:
                self.image = pygame.transform.scale(goomba_img, (UNIT,UNIT))
            else:
                self.image = pygame.transform.flip(pygame.transform.scale(goomba_img, (UNIT,UNIT)), True, False)
            self.image.set_colorkey(WHITE)

class Brick(pygame.sprite.Sprite):
    def __init__(self, x, y):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.transform.scale(brick_img, (UNIT,UNIT))
        self.rect = self.image.get_rect()

        self.rect.x = x * UNIT
        self.rect.y = y * UNIT


# Initialize pygame and create window
pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('My Game')
clock = pygame.time.Clock()

goomba_img = pygame.image.load(path.join(img_dir, 'goomba.png')).convert()
brick_img = pygame.image.load(path.join(img_dir, 'brick.png')).convert()

all_sprites = pygame.sprite.Group()
brick_list = pygame.sprite.Group()

goomba = Goomba()
all_sprites.add(goomba)

bricks = [ [0,4], [0,5], [1,5], [2,5], [3,5], [4,5], [5,5], [6,5], [7,5], [7,4] ]

for location in bricks:
    brick = Brick(location[0], location[1])
    brick_list.add(brick)
    all_sprites.add(brick)

# Game loop
running = True
while running:
    # Control game speed
    clock.tick(FPS)

    # Events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                pass
        
    # Update
    all_sprites.update()

    # Render
    screen.fill(BLUE)
    all_sprites.draw(screen)

    pygame.display.flip()
    
pygame.quit()
